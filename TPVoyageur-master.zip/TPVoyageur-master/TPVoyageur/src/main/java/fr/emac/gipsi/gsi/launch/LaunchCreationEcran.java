/**
 * 
 */
package fr.emac.gipsi.gsi.launch;

import fr.emac.gipsi.gsi.gui.InterfaceCreationEcran;

/**
 * @author Truptil Sebastien - sebastien.truptil@gmail.com
 *
 */
public class LaunchCreationEcran {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		InterfaceCreationEcran ice = new InterfaceCreationEcran();
		ice.setVisible(true);
		
	}

}
